﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projekat_7
{
    public partial class Form1 : Form
    {
        List<Button> dodeli = new List<Button>();
        int brtacaka = 11;
        
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 23; i++)
            {
                button2.PerformClick();
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Random broj = new Random();
            Random mina = new Random();
            brtacaka++;
            for(int i = 0; i < brtacaka; i++)
            {
                Button taster = new Button();
                panel2.Controls.Add(taster);
                int x, y;
                x = broj.Next(0, 14);
                y = broj.Next(0, 13);
                taster.Location = new Point(x * 30, y * 30);
                taster.Size = new Size(30, 30);
                int z1 = broj.Next(0, 255);
                int z2 = broj.Next(0, 255);
                int z3 = broj.Next(0, 255);
                taster.BackColor = System.Drawing.Color.FromArgb(z1, z2, z3);
                int m = mina.Next(0, 10);
                dodeli.Insert(0, taster);

                Button koji = dodeli[i];
                if (koji.Bounds.IntersectsWith(koji.Bounds))
                    koji.Dispose();

                taster.Click += (s, args) =>
                {
                     taster.Visible = false;
                    if (m == 8)
                     {
                        MessageBox.Show("Kliknuo si na minu!");
                        this.Close();
                    }
                };
            }
        }
    }
}
