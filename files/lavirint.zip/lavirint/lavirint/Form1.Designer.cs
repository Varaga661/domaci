﻿namespace lavirint
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button7 = new Button();
            button9 = new Button();
            panel1 = new Panel();
            label1 = new Label();
            button10 = new Button();
            button11 = new Button();
            timer1 = new System.Windows.Forms.Timer(components);
            timer2 = new System.Windows.Forms.Timer(components);
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackColor = Color.Red;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Location = new Point(59, 437);
            button1.Name = "button1";
            button1.Size = new Size(47, 41);
            button1.TabIndex = 0;
            button1.UseVisualStyleBackColor = false;
            button1.KeyPress += button1_KeyPress;
            // 
            // button2
            // 
            button2.BackColor = Color.Salmon;
            button2.BackgroundImageLayout = ImageLayout.Center;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Location = new Point(0, 343);
            button2.Name = "button2";
            button2.Size = new Size(217, 43);
            button2.TabIndex = 1;
            button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            button3.BackColor = Color.Salmon;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Location = new Point(362, 336);
            button3.Name = "button3";
            button3.Size = new Size(37, 186);
            button3.TabIndex = 2;
            button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            button4.BackColor = Color.Salmon;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Location = new Point(180, 80);
            button4.Name = "button4";
            button4.Size = new Size(37, 266);
            button4.TabIndex = 3;
            button4.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            button5.BackColor = Color.Salmon;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Location = new Point(286, 303);
            button5.Name = "button5";
            button5.Size = new Size(113, 34);
            button5.TabIndex = 4;
            button5.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            button7.BackColor = Color.Salmon;
            button7.FlatStyle = FlatStyle.Flat;
            button7.Location = new Point(390, 303);
            button7.Name = "button7";
            button7.Size = new Size(336, 34);
            button7.TabIndex = 6;
            button7.UseVisualStyleBackColor = false;
            // 
            // button9
            // 
            button9.BackColor = Color.SeaGreen;
            button9.FlatStyle = FlatStyle.Popup;
            button9.Location = new Point(0, 190);
            button9.Name = "button9";
            button9.Size = new Size(47, 46);
            button9.TabIndex = 8;
            button9.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ActiveBorder;
            panel1.Controls.Add(label1);
            panel1.Controls.Add(button10);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(891, 82);
            panel1.TabIndex = 9;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(460, 33);
            label1.Name = "label1";
            label1.Size = new Size(25, 20);
            label1.TabIndex = 1;
            label1.Text = "50";
            // 
            // button10
            // 
            button10.Location = new Point(30, 12);
            button10.Name = "button10";
            button10.Size = new Size(213, 41);
            button10.TabIndex = 0;
            button10.Text = "START";
            button10.UseVisualStyleBackColor = true;
            button10.Click += button10_Click;
            // 
            // button11
            // 
            button11.Location = new Point(653, 430);
            button11.Name = "button11";
            button11.Size = new Size(86, 54);
            button11.TabIndex = 10;
            button11.Text = "KRAJ";
            button11.UseVisualStyleBackColor = true;
            // 
            // timer1
            // 
            timer1.Interval = 1;
            timer1.Tick += timer1_Tick;
            // 
            // timer2
            // 
            timer2.Interval = 1000;
            timer2.Tick += timer2_Tick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(891, 520);
            Controls.Add(button11);
            Controls.Add(panel1);
            Controls.Add(button1);
            Controls.Add(button9);
            Controls.Add(button7);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Name = "Form1";
            Text = "Form1";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button7;
        private Button button9;
        private Panel panel1;
        private Button button10;
        private Button button11;
        private System.Windows.Forms.Timer timer1;
        private Label label1;
        private System.Windows.Forms.Timer timer2;
    }
}
