namespace lavirint
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            label1.Text = "50";
            timer1.Start();
            button1.Focus();
            button1.Left = 30;
            button1.Top = 428;
            timer2.Start();

        }

        private void button1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 'a') button1.Left -= 10;
            if (e.KeyChar == 's') button1.Top += 10;
            if (e.KeyChar == 'd') button1.Left += 10;
            if (e.KeyChar == 'w') button1.Top -= 10;

            if (button1.Left < -19) button1.Left = -10;
            if (button1.Left > 864) button1.Left = 860;
            if (button1.Top < 59) button1.Top = 50;
            if (button1.Top > 490) button1.Top = 480;

            if (button1.Bounds.IntersectsWith(button2.Bounds))
            {
                button1.Left = 40;
                button1.Top = 429;
            }
            if (button1.Bounds.IntersectsWith(button3.Bounds))
            {
                button1.Left = 40;
                button1.Top = 429;
            }
            if (button1.Bounds.IntersectsWith(button4.Bounds))
            {
                button1.Left = 40;
                button1.Top = 429;
            }
            if (button1.Bounds.IntersectsWith(button5.Bounds))
            {
                button1.Left = 40;
                button1.Top = 429;
            }

            if (button1.Bounds.IntersectsWith(button7.Bounds))
            {
                button1.Left = 40;
                button1.Top = 429;
            }

            if (button1.Bounds.IntersectsWith(button9.Bounds))
            {
                button1.Left = 40;
                button1.Top = 429;
            }
            if (button1.Bounds.IntersectsWith(button11.Bounds))
            {
                timer1.Stop();
                timer2.Stop();
                MessageBox.Show("THE END");

            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            button9.Left += 5;
            if (button9.Left > 857)
                button9.Left = 0;
            

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            int vreme = Convert.ToInt16(label1.Text);
            vreme--;
            label1.Text = Convert.ToString(vreme);
            if (vreme == 0)
            {
                timer2.Stop();
                MessageBox.Show("GAME OVER");
                button1.Left = 40;
                button1.Top = 429;
                timer1.Stop();

            }
        }
    }
}
