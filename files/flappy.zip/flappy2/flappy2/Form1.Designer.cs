﻿namespace flappy2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            panel1 = new Panel();
            label1 = new Label();
            button10 = new Button();
            timer1 = new System.Windows.Forms.Timer(components);
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackgroundImage = (Image)resources.GetObject("button1.BackgroundImage");
            button1.BackgroundImageLayout = ImageLayout.Stretch;
            button1.Location = new Point(23, 296);
            button1.Name = "button1";
            button1.Size = new Size(47, 41);
            button1.TabIndex = 0;
            button1.UseVisualStyleBackColor = true;
            button1.KeyPress += button1_KeyPress;
            // 
            // button2
            // 
            button2.BackColor = Color.Lime;
            button2.BackgroundImageLayout = ImageLayout.Stretch;
            button2.Location = new Point(281, 89);
            button2.Name = "button2";
            button2.Size = new Size(28, 170);
            button2.TabIndex = 1;
            button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            button3.BackColor = Color.Lime;
            button3.BackgroundImageLayout = ImageLayout.Stretch;
            button3.Location = new Point(281, 384);
            button3.Name = "button3";
            button3.Size = new Size(28, 150);
            button3.TabIndex = 2;
            button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            button4.BackColor = Color.Lime;
            button4.Location = new Point(444, 89);
            button4.Name = "button4";
            button4.Size = new Size(28, 230);
            button4.TabIndex = 3;
            button4.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            button5.BackColor = Color.Lime;
            button5.Location = new Point(444, 444);
            button5.Name = "button5";
            button5.Size = new Size(28, 90);
            button5.TabIndex = 4;
            button5.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            button6.BackColor = Color.Lime;
            button6.Location = new Point(607, 89);
            button6.Name = "button6";
            button6.Size = new Size(28, 90);
            button6.TabIndex = 5;
            button6.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            button7.BackColor = Color.Lime;
            button7.Location = new Point(607, 304);
            button7.Name = "button7";
            button7.Size = new Size(28, 230);
            button7.TabIndex = 6;
            button7.UseVisualStyleBackColor = false;
            // 
            // button8
            // 
            button8.BackColor = Color.Lime;
            button8.Location = new Point(756, 89);
            button8.Name = "button8";
            button8.Size = new Size(28, 170);
            button8.TabIndex = 7;
            button8.UseVisualStyleBackColor = false;
            // 
            // button9
            // 
            button9.BackColor = Color.Lime;
            button9.Location = new Point(756, 384);
            button9.Name = "button9";
            button9.Size = new Size(28, 150);
            button9.TabIndex = 8;
            button9.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            panel1.Controls.Add(label1);
            panel1.Controls.Add(button10);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(860, 92);
            panel1.TabIndex = 9;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(607, 37);
            label1.Name = "label1";
            label1.Size = new Size(17, 20);
            label1.TabIndex = 1;
            label1.Text = "0";
            // 
            // button10
            // 
            button10.Location = new Point(23, 22);
            button10.Name = "button10";
            button10.Size = new Size(130, 50);
            button10.TabIndex = 0;
            button10.Text = "START";
            button10.UseVisualStyleBackColor = true;
            button10.Click += button10_Click;
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(860, 532);
            Controls.Add(panel1);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Panel panel1;
        private Label label1;
        private Button button10;
        private System.Windows.Forms.Timer timer1;
    }
}
