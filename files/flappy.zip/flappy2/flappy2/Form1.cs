namespace flappy2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            button1.Top += 10;
            button2.Left -= 5;
            button3.Left -= 5;
            button4.Left -= 5;
            button5.Left -= 5;
            button6.Left -= 5;
            button7.Left -= 5;
            button8.Left -= 5;
            button9.Left -= 5;
            int poeni = Convert.ToInt16(label1.Text);
            Random x = new Random();
            if (button2.Left < -12)
            {
                button2.Left = 832;
                button3.Left = 832;
                int visina1 = x.Next(280);
                int visina2 = 445 - (visina1 + 80);
                button2.Height = visina1;
                button3.Height = visina2;
                button3.Top = visina1 + 80;
                poeni++;

            }

            if (button4.Left < -12)
            {
                button4.Left = 832;
                button5.Left = 832;
                int visina1 = x.Next(280);
                int visina2 = 445 - (visina1 + 80);
                button4.Height = visina1;
                button5.Height = visina2;
                button4.Top = visina1 + 80;
                poeni++;

            }

            if (button6.Left < -12)
            {
                button6.Left = 832;
                button7.Left = 832;
                int visina1 = x.Next(280);
                int visina2 = 445 - (visina1 + 80);
                button6.Height = visina1;
                button7.Height = visina2;
                button7.Top = visina1 + 80;
                poeni++;

            }
            if (button8.Left < -12)
            {
                button8.Left = 832;
                button9.Left = 832;
                int visina1 = x.Next(280);
                int visina2 = 445 - (visina1 + 80);
                button8.Height = visina1;
                button9.Height = visina2;
                button9.Top = visina1 + 80;
                poeni++;

            }

            label1.Text = Convert.ToString(poeni);

        }

        private void button10_Click(object sender, EventArgs e)
        {
            timer1.Start();
            label1.Text = "0";
            button1.Focus();

        }

        private void button1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 'w') button1.Top -= 30;
            if (button1.Bounds.IntersectsWith(button2.Bounds))
            {
                timer1.Stop();
                MessageBox.Show("GAME OVER");
            }
            if (button1.Bounds.IntersectsWith(button3.Bounds))
            {
                timer1.Stop();
                MessageBox.Show("GAME OVER");
            }
            if (button1.Bounds.IntersectsWith(button4.Bounds))
            {
                timer1.Stop();
                MessageBox.Show("GAME OVER");
            }
            if (button1.Bounds.IntersectsWith(button5.Bounds))
            {
                timer1.Stop();
                MessageBox.Show("GAME OVER");
            }
            if (button1.Bounds.IntersectsWith(button6.Bounds))
            {
                timer1.Stop();
                MessageBox.Show("GAME OVER");
            }
            if (button1.Bounds.IntersectsWith(button7.Bounds))
            {
                timer1.Stop();
                MessageBox.Show("GAME OVER");
            }
            if (button1.Bounds.IntersectsWith(button8.Bounds))
            {
                timer1.Stop();
                MessageBox.Show("GAME OVER");
            }
            if (button1.Bounds.IntersectsWith(button9.Bounds))
            {
                timer1.Stop();
                MessageBox.Show("GAME OVER");
            }

        }
    }
}
