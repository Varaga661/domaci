﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prodavnica
{
    public partial class Form1 : Form
    {
        int krajnacena = 0;
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panel1.BackColor = Color.FromArgb(200, 0, 0, 0);
            panel2.BackColor = Color.FromArgb(200, 0, 0, 0);
            panel3.BackColor = Color.FromArgb(200, 0, 0, 0);
            panel4.BackColor = Color.FromArgb(200, 0, 0, 0);
            panel5.BackColor = Color.FromArgb(200, 0, 0, 0);
            panel6.BackColor = Color.FromArgb(200, 0, 0, 0);
            panel7.BackColor = Color.FromArgb(200, 0, 0, 0);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage2;
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage3;
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage4;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage5;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage7;
            textBox16.Text = "0";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage6;
        }

        private void tabPage5_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            int index = listBox1.SelectedIndex;

            textBox1.Text = listBox1.Items[index].ToString();
            listBox2.SelectedIndex = index;
            textBox2.Text = listBox2.Items[index].ToString();
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            /*int kolicina = 0;

            if (e.KeyChar == 'w')
            {
                kolicina++;
                textBox3.Text = kolicina.ToString();
            }
            else if (e.KeyChar == 's')
            {
                if (kolicina > 0) kolicina--; 
                textBox3.Text = kolicina.ToString();
            }*/
        }

        private void button7_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage7;
            

            string artikal = textBox1.Text;
            string cena = textBox2.Text;
            string kolicina = textBox3.Text;

            
            if (string.IsNullOrWhiteSpace(artikal) || string.IsNullOrWhiteSpace(cena) || string.IsNullOrWhiteSpace(kolicina))
            {
                MessageBox.Show("Popuni sve podatke pre dodavanja u kasu!");
                return;
            }

            int cena1 = Convert.ToInt16(textBox2.Text);
            int kol1 = Convert.ToInt16(textBox3.Text);

            int ukupno = cena1 * kol1;
            krajnacena = krajnacena + ukupno;
            textBox16.Text = Convert.ToString(krajnacena);


                listBox18.Items.Add(artikal);
                listBox17.Items.Add(cena.ToString());
                listBox16.Items.Add(ukupno.ToString());
            
        }

        private void listBox6_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = listBox6.SelectedIndex;

            textBox6.Text = listBox6.Items[index].ToString();
            listBox5.SelectedIndex = index;
            textBox5.Text = listBox5.Items[index].ToString();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage7;
            

            string artikal = textBox6.Text;
            string cena = textBox5.Text;
            string kolicina = textBox4.Text;


            if (string.IsNullOrWhiteSpace(artikal) || string.IsNullOrWhiteSpace(cena) || string.IsNullOrWhiteSpace(kolicina))
            {
                MessageBox.Show("Popuni sve podatke pre dodavanja u kasu!");
                return;
            }

            int cena1 = Convert.ToInt16(textBox5.Text);
            int kol1 = Convert.ToInt16(textBox4.Text);

            int ukupno = cena1 * kol1;
            krajnacena = krajnacena + ukupno;
            textBox16.Text = Convert.ToString(krajnacena);


            listBox18.Items.Add(artikal);
            listBox17.Items.Add(cena.ToString());
            listBox16.Items.Add(ukupno.ToString());
        }

        private void listBox9_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = listBox9.SelectedIndex;

            textBox9.Text = listBox9.Items[index].ToString();
            listBox8.SelectedIndex = index;
            textBox8.Text = listBox8.Items[index].ToString();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage7;

            string artikal = textBox9.Text;
            string cena = textBox8.Text;
            string kolicina = textBox7.Text;


            if (string.IsNullOrWhiteSpace(artikal) || string.IsNullOrWhiteSpace(cena) || string.IsNullOrWhiteSpace(kolicina))
            {
                MessageBox.Show("Popuni sve podatke pre dodavanja u kasu!");
                return;
            }

            int cena1 = Convert.ToInt16(textBox8.Text);
            int kol1 = Convert.ToInt16(textBox7.Text);

            int ukupno = cena1 * kol1;
            krajnacena = krajnacena + ukupno;
            textBox16.Text = Convert.ToString(krajnacena);


            listBox18.Items.Add(artikal);
            listBox17.Items.Add(cena.ToString());
            listBox16.Items.Add(ukupno.ToString());
        }

        private void listBox12_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = listBox12.SelectedIndex;

            textBox12.Text = listBox12.Items[index].ToString();
            listBox11.SelectedIndex = index;
            textBox11.Text = listBox11.Items[index].ToString();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage7;

            string artikal = textBox12.Text;
            string cena = textBox11.Text;
            string kolicina = textBox10.Text;


            if (string.IsNullOrWhiteSpace(artikal) || string.IsNullOrWhiteSpace(cena) || string.IsNullOrWhiteSpace(kolicina))
            {
                MessageBox.Show("Popuni sve podatke pre dodavanja u kasu!");
                return;
            }

            int cena1 = Convert.ToInt16(textBox11.Text);
            int kol1 = Convert.ToInt16(textBox10.Text);

            int ukupno = cena1 * kol1;
            krajnacena = krajnacena + ukupno;
            textBox16.Text = Convert.ToString(krajnacena);


            listBox18.Items.Add(artikal);
            listBox17.Items.Add(cena.ToString());
            listBox16.Items.Add(ukupno.ToString());
        }

        private void listBox15_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = listBox15.SelectedIndex;

            textBox15.Text = listBox15.Items[index].ToString();
            listBox14.SelectedIndex = index;
            textBox14.Text = listBox14.Items[index].ToString();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage7;

            string artikal = textBox15.Text;
            string cena = textBox14.Text;
            string kolicina = textBox13.Text;


            if (string.IsNullOrWhiteSpace(artikal) || string.IsNullOrWhiteSpace(cena) || string.IsNullOrWhiteSpace(kolicina))
            {
                MessageBox.Show("Popuni sve podatke pre dodavanja u kasu!");
                return;
            }

            int cena1 = Convert.ToInt16(textBox14.Text);
            int kol1 = Convert.ToInt16(textBox13.Text);

            int ukupno = cena1 * kol1;
            krajnacena = krajnacena + ukupno;
            textBox16.Text = Convert.ToString(krajnacena);


            listBox18.Items.Add(artikal);
            listBox17.Items.Add(cena.ToString());
            listBox16.Items.Add(ukupno.ToString());
        }

        private void button13_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage1;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            listBox18.Items.Clear();
            listBox17.Items.Clear();
            listBox16.Items.Clear();
            textBox16.Clear();
            MessageBox.Show("Čestitamo na vašoj kupovini!!");
        }
    }
}
