namespace klikometar2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label4.Text = "10";
            label1.Text = "0";
            button2.Enabled = true;
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            int vreme = Convert.ToInt32(label4.Text);
            vreme--;
            label4.Text = Convert.ToString(vreme);
            if (label4.Text == "0")
            {
                timer1.Stop();
                button2.Enabled = false;
                MessageBox.Show(" GAME OVER ");

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
