﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Shooting_Star
{
    public partial class Form1 : Form
    {
        int pravac;
        

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Imas 4 zivota ako i jedan od pravugaonika padne ispod gubis zovot");
            timer1.Start();
            button2.Focus();
        }

        private void button2_KeyPress(object sender, KeyPressEventArgs e)
        {
            
            if (e.KeyChar == 'a') pravac=0;
            if (e.KeyChar == 'd') pravac=1;

            if (e.KeyChar == ' ' )
            {
                button3.Left = button2.Left + 20;
                button3.Top = button2.Top + 20;
                timer2.Start();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (pravac==0) button2.Left -= 10;
            if (pravac==1) button2.Left += 10;
            button4.Top += 2;
            button5.Top += 3;
            button6.Top += 4;
            if (button2.Left >= 796) button2.Left = -28;
            if (button2.Left <= -30) button2.Left = 793;
            if(button4.Top>420)
            {
                button4.Top = 0;

                if (button10.Left == 706) button10.Left = 1000;
                else if (button10.Left == 1000 && button9.Left == 680) button9.Left = 1000;
                else if (button9.Left == 1000 && button8.Left == 654) button8.Left = 1000;
                else if (button8.Left == 1000 && button7.Left == 628)
                {
                    timer1.Stop();
                    MessageBox.Show("EHH...");
                    MessageBox.Show("Tako je kratko trajalo...");
                    MessageBox.Show("Šta ćeš...");
                    MessageBox.Show("IZGUBIO SI!! MRTAV SI!!");
                }
            }
            if (button5.Top > 420)
            {
                button5.Top = 0;

                if (button10.Left == 706) button10.Left = 1000;
                else if (button10.Left == 1000 && button9.Left == 680) button9.Left = 1000;
                else if (button9.Left == 1000 && button8.Left == 654) button8.Left = 1000;
                else if (button8.Left == 1000 && button7.Left == 628)
                {
                    timer1.Stop();
                    MessageBox.Show("EHH...");
                    MessageBox.Show("Tako je kratko trajalo...");
                    MessageBox.Show("Šta ćeš...");
                    MessageBox.Show("IZGUBIO SI!! MRTAV SI!!");
                }
            }
            if (button6.Top > 420)
            {
                button6.Top = 0;

                if (button10.Left == 706) button10.Left = 1000;
                else if (button10.Left == 1000 && button9.Left == 680) button9.Left = 1000;
                else if (button9.Left == 1000 && button8.Left == 654) button8.Left = 1000;
                else if (button8.Left == 1000 && button7.Left == 628)
                {
                    timer1.Stop();
                    MessageBox.Show("EHH...");
                    MessageBox.Show("Tako je kratko trajalo...");
                    MessageBox.Show("Šta ćeš...");
                    MessageBox.Show("IZGUBIO SI!! MRTAV SI!!");
                }
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            int poeni = Convert.ToInt16(label2.Text);
            button3.Top -= 30;
            Random x = new Random();
            if (button3.Bounds.IntersectsWith(button4.Bounds))
            {
                button4.Top = 0;
                int poz = x.Next(0, 714);
                button4.Left = poz;
                timer2.Stop();
                button3.Top = 500;
                poeni++;
                label2.Text = Convert.ToString(poeni);
            }
            if (button3.Bounds.IntersectsWith(button5.Bounds))
            {
                button5.Top = 0;
                int poz = x.Next(0, 714);
                button5.Left = poz;
                timer2.Stop();
                button3.Top = 500;
                poeni++;
                label2.Text = Convert.ToString(poeni);
            }
            if (button3.Bounds.IntersectsWith(button6.Bounds))
            {
                button6.Top = 0;
                int poz = x.Next(0, 714);
                button6.Left = poz;
                timer2.Stop();
                button3.Top = 500;
                poeni++;
                label2.Text = Convert.ToString(poeni);
            }
            
        }
    }
}
